## Facial Analysis - Study Data

This folder contains data for paper
`Yegor Tkachenko, Kamel Jedidi. A Megastudy on the Predictability of Personal Information from Facial Images (2023).`

This data is available online from `https://github.com/computationalmarketing/facialanalysis`.

Study participants have consented to the public release of their data (see the online repository for the IRB consent form respondents had to complete before they could upload images and complete the questionnaire). 

## Data Description

`./data.csv` contains binarized survey responses together with `randomID` identifier for the respondent and `img_path` showing path to one of the images of the respondent. For each respondent, there are up to 3 associated images, which translates into up to 3 rows in this file, with duplicated survey responses, but different image paths.

`./images/image_features.csv` contains image path together with metrics describing the image, including: (1-3) RGB color channels averaged across face oval; (4) facial width-to-height ratio (fWHR) that has been connected to aggressive personality (Carr ́e and McCormick, 2008); (5) face width; (6) face height; (7) nose height; (8) difference in the height of the eyes; (9) inter-eye horizontal difference; (10) mouth (lip) width; and (11) a ratio between distances from face edges to the proximate eyes.

`./images/Q8`, `./images/Q9`, `./images/Q10` contain the facial images (both full images as well as the versions where all area around the face is blacked out or 'cropped').

See paper for details.


